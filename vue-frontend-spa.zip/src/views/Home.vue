<template>
  <div class="row">
    <div class="col text-center">
      <img alt="Vue logo" src="../assets/logo.png">

      <h4 class="mt-5">A Vue.js Frontend Starter Kit / Boilerplate</h4>
      <p>Laravel 6 Backend API Ready</p>
    </div>
  </div>
</template>

<script>
export default {
  components: {
    //
  },

  metaInfo () {
    return { title: this.$t('home') }
  }
}
</script>
