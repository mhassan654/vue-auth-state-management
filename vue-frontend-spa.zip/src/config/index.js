export const APP_NAME = 'Application'
